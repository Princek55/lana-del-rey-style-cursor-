Lana Del Rey cursor pack (.cur + .ani)
Install: Settings > Bluetooth & devices > Mouse > Additional mouse settings > Pointers tab.
Select a role, click Browse, pick the file, Apply.

Suggested mapping:
Normal Select      -> cur/Normal_Select.cur
Help Select        -> cur/Help.cur
Working in Bkgrnd  -> ani/Working_in_Background.ani
Busy               -> ani/Busy_Alt.ani
Precision Select   -> cur/Precision_Select.cur
Text Select        -> cur/Text_Select.cur
Handwriting        -> cur/Handwriting.cur
Unavailable        -> cur/Not_Allowed.cur
Vertical Resize    -> cur/Vertical_Resize.cur
Horizontal Resize  -> cur/Horizontal_Resize.cur
Diagonal Resize 1  -> cur/Diagonal_Resize_1.cur
Diagonal Resize 2  -> cur/Diagonal_Resize_2.cur
Move               -> cur/Move.cur
Alternate Select   -> cur/Alternate_Select.cur
Link Select        -> cur/Link.cur
Extras: Folder, File, Search, Select, Available, Unavailable, Wait, Busy, Vertical_Text_Select.
